exec		sql define REGRESSDB1 ecpg1_regression;
exec		sql define REGRESSDB2 ecpg2_regression;

exec		sql define REGRESSUSER1 regress_ecpg_user1;
exec		sql define REGRESSUSER2 regress_ecpg_user2;
