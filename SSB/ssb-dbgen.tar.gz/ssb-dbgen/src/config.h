/* 
 * An explanations of some of the #define's added by this file (that 
 * don't directly originate from CMake configuration choices):
 *   SEPARATOR         -- character used to separate fields in flat files
 *   DSS_HUGE          -- 64 bit data type
 *   HUGE_FORMAT       -- printf string for 64 bit data type
 *   HUGE_COUNT        -- number of objects in DSS_HUGE
 *   DSS_PROC          -- a process-id-based random seeding factor
 *
 * DATABASE values, explained:
 *   DB2        -- use the IBM DB2 dialect in QGEN
 *   INFORMIX   -- use the Informix dialect in QGEN
 *   SQLSERVER  -- use the Microsoft SQL Server dialect in QGEN
 *   SYBASE     -- use the Sybase dialect in QGEN
 *   TDAT       -- use Teradata dialect in QGEN
 */

/* POSIX platform headers */
#define HAVE_UNISTD_H
#define HAVE_FCNTL_H
#define HAVE_SYS_WAIT_H
#define HAVE_SYS_TYPES_H
#define HAVE_SYS_STAT_H
#define HAVE_STRINGS_H
#define HAVE_INTTYPES_H

/* Windows platform headers */
/* #undef HAVE_PROCESS_H */
/* #undef HAVE_WINDOWS_H */

/* Non-platform-specific headers */
#define HAVE_STDINT_H
/* #undef HAVE_SYS_BITTYPES_H */
#define HAVE_MALLOC_IN_STDLIB
/* #undef HAVE_MALLOC_H */

#define RNG_TEST
#define _FILE_OFFSET_BITS 64

/* SIZEOF_LONG check */
#if (8 == 8)
#define SIGNED_64_BIT_C_TYPE long
#define SIGNED_64_BIT_PRINTF_MODIFIER "l"
#else
/* SIZEOF_LONG_LONG check */
#if (8 == 8)
#define SIGNED_64_BIT_C_TYPE long long
#define SIGNED_64_BIT_PRINTF_MODIFIER "ll"
#else
/* SIZEOF_SHORT check */
#if (2 == 8)
#define SIGNED_64_BIT_C_TYPE short
#define SIGNED_64_BIT_PRINTF_MODIFIER "s"
#else
/* SIZEOF_INT check */
#if (4 == 8)
#define SIGNED_64_BIT_C_TYPE int
#define SIGNED_64_BIT_PRINTF_MODIFIER
#else
#error "No standard C integer type has size 8"
#endif
#endif
#endif
#endif

#define SUPPORT_64BITS

#define DSS_HUGE          SIGNED_64_BIT_C_TYPE
#define HUGE_FORMAT_SPECIFIER  SIGNED_64_BIT_PRINTF_MODIFIER "d"
#define HUGE_FORMAT       "%" HUGE_FORMAT_SPECIFIER
#define HUGE_COUNT        1
#define HUGE_DATE_FORMAT  "%02" HUGE_FORMAT_SPECIFIER

#define CSV_OUTPUT_FORMAT 0
#if CSV_OUTPUT_FORMAT 
#define SEPARATOR ',' /* field spearator for generated flat files */
#define DOUBLE_QUOTE_OUTPUT_STRINGS /* In the SSB data set, we may have commas in strings, so let's enclose (all of) them in quotes. */
#ifndef EOL_HANDLING
#define EOL_HANDLING /* Note: This should already be defined by CMake; only "emphasizing" here */
#endif
#else
#define SEPARATOR '|'
#endif

#define EOL_HANDLING
/* #undef YMD_DASH_DATE */

#define HAVE_GETOPT_H
/* #undef STDLIB_HAS_GETOPT */
#define STDLIB_HAS_GETENV

#if (defined(STDLIB_HAS_GETOPT) || defined(HAVE_GETOPT_H))
    #define HAVE_GETOPT
#endif

#define HAVE_GETPID 0
#if (HAVE_GETPID == 1)
#define DSS_PROC getpid()
#else
#define DSS_PROC 1
#endif

#define HAVE_KILL
#define HAVE_FORK
#define HAVE_WAIT

#define RNG_A	6364136223846793005ull
#define RNG_C	1ull

#if (defined(_WIN32) && !defined(_POSIX)) || defined(__CYGWIN__)
#define PATH_SEP '\\'
#else
#define PATH_SEP '/'
#endif

#if (!defined(HAVE_UNISTD_H) && !defined(HAVE_PID_T_IN_SYS_TYPES_H))
	typedef int pid_t;
#endif

#ifdef _MSC_VER

/* Disable warnings about "foo() converted to foo(void)" */
#pragma warning(disable:4255)

/* Disable warnings about "added padding to struct data members" */
#pragma warning(disable:4820)

/* Disable warnings about "function not inlined" */
#pragma warning(disable:4710)
#endif

